package com.example.skilltest

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
